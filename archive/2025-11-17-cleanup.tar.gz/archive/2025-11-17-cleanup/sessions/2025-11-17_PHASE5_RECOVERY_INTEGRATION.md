# Phase 5 Recovery System - Integration Documentation

## Overview

The Phase 5 Recovery System is now fully integrated into the **layered automation architecture** for detecting and filling missing baskets after rate limits, agent failures, or quality issues.

---

## Architecture Integration

```
┌─────────────────────────────────────────────────────────────┐
│              Dashboard UI (Vercel)                          │
│  - "Recover Missing Baskets" button                         │
│  - Shows missing count and progress                         │
└──────────────────────┬──────────────────────────────────────┘
                       │ HTTP POST
                       ▼
┌─────────────────────────────────────────────────────────────┐
│         Phase 5 Basket Server (Port 3459)                   │
│  POST /recovery                                             │
│  GET /recovery/status/:courseCode                           │
└──────────────────────┬──────────────────────────────────────┘
                       │ requires
                       ▼
┌─────────────────────────────────────────────────────────────┐
│    services/phase5_recovery_orchestrator.cjs                │
│  - Detects gaps from GitHub branches                        │
│  - Calculates optimal seeds-per-agent                       │
│  - Generates 12 orchestrator prompts                        │
│  - Launches Safari/Claude Code tabs                         │
└──────────────────────┬──────────────────────────────────────┘
                       │ uses
       ┌───────────────┼───────────────┐
       ▼               ▼               ▼
scripts/detect_    scripts/generate_  Safari
missing_           recovery_          osascript
baskets.cjs        prompts.cjs
```

---

## Configuration

### automation.config.json

Recovery configuration added under `phase5_basket_generation.recovery_mode`:

```json
{
  "phase5_basket_generation": {
    "recovery_mode": {
      "detection": {
        "auto_detect_gaps": true,
        "github_branch_pattern": "baskets-{courseCode}-*",
        "expected_total_seeds": 668
      },
      "parallelization": {
        "fixed_windows": 12,
        "fixed_agents_per_window": 10,
        "variable_seeds_per_agent": "calculated (missing_seeds / 12 / 10)"
      },
      "browser_sessions": {
        "max_concurrent_browsers": 12,
        "use_safari": true
      },
      "quality_triggers": {
        "auto_recovery_on_rate_limit": true,
        "auto_recovery_on_validation_failure": false
      }
    }
  }
}
```

---

## API Endpoints

### POST /recovery

Initiates recovery for a course by detecting missing baskets and launching orchestrators.

**Request:**
```bash
curl -X POST http://localhost:3459/recovery \
  -H "Content-Type: application/json" \
  -d '{
    "courseCode": "cmn_for_eng",
    "autoLaunch": true
  }'
```

**Response (Recovery Needed):**
```json
{
  "success": true,
  "recovery_initiated": true,
  "missing_seeds": 243,
  "recovery_params": {
    "num_windows": 12,
    "agents_per_window": 10,
    "seeds_per_agent": 3
  },
  "prompts": {
    "count": 12,
    "directory": ".claude/recovery_prompts",
    "files": ["window_01.md", "window_02.md", ...]
  },
  "next_steps": [
    "Wait for Claude Code tabs to load",
    "Paste corresponding prompt in each tab",
    "Replace {SESSION_ID} with actual session ID",
    "Monitor progress via GitHub branches"
  ]
}
```

**Response (No Recovery Needed):**
```json
{
  "success": true,
  "recovery_initiated": false,
  "message": "No missing baskets - all complete!"
}
```

---

### GET /recovery/status/:courseCode

Check recovery progress.

**Request:**
```bash
curl http://localhost:3459/recovery/status/cmn_for_eng
```

**Response:**
```json
{
  "status": "in_progress",
  "initial_missing": 243,
  "current_missing": 120,
  "filled": 123,
  "progress": "50.6%",
  "remaining_seeds": [133, 134, 135, ...]
}
```

---

## Components

### 1. scripts/detect_missing_baskets.cjs

**Purpose:** Analyzes GitHub branches to find missing baskets

**Usage:**
```bash
node scripts/detect_missing_baskets.cjs cmn_for_eng
```

**Output:**
- Console summary of missing seeds
- `missing_seeds.json` with structured gap analysis

**Algorithm:**
1. Fetch all remote `baskets-{courseCode}-*` branches
2. Run `git ls-tree` on each branch to list files
3. Extract seed numbers from basket filenames
4. Compare against expected 668 seeds
5. Calculate missing seeds and group into ranges

---

### 2. scripts/generate_recovery_prompts.cjs

**Purpose:** Generates 12 orchestrator prompts for recovery

**Usage:**
```bash
node scripts/generate_recovery_prompts.cjs cmn_for_eng
```

**Output:**
- 12 markdown files in `.claude/recovery_prompts/`
- Each prompt is ready to paste into Claude Code

**Template Features:**
- Includes scaffold generation script
- Pre-calculates agent seed assignments
- Contains git commands for branch/commit/push
- Verification commands included

---

### 3. services/phase5_recovery_orchestrator.cjs

**Purpose:** Main recovery orchestration service

**Can be used:**
- As Node.js module (required by Phase 5 server)
- As standalone CLI

**Standalone CLI:**
```bash
node services/phase5_recovery_orchestrator.cjs cmn_for_eng
node services/phase5_recovery_orchestrator.cjs cmn_for_eng --no-launch
```

**Methods:**
- `runRecovery(courseCode, options)` - Main recovery workflow
- `detectGaps(courseCode)` - Run gap detection
- `generatePrompts(courseCode, analysis)` - Generate prompts
- `launchBrowsers(count)` - Launch Safari tabs
- `checkStatus(courseCode)` - Check recovery progress

---

## Workflow

### Full Recovery Workflow

1. **User triggers recovery** (from Dashboard or API)
   ```javascript
   POST /recovery
   {
     "courseCode": "cmn_for_eng",
     "autoLaunch": true
   }
   ```

2. **Gap detection runs**
   - Fetches all GitHub branches
   - Analyzes what's been pushed
   - Identifies 243 missing seeds

3. **Prompts generated**
   - Divides 243 seeds across 12 windows
   - Each window gets ~20 seeds
   - 10 agents per window, 2-3 seeds per agent
   - Prompts saved to `.claude/recovery_prompts/`

4. **Safari launches**
   - Opens 12 Claude Code tabs
   - Each tab ready for its prompt

5. **User pastes prompts**
   - Copy from `.claude/recovery_prompts/window_01.md`
   - Paste into corresponding tab
   - Replace `{SESSION_ID}` with actual ID
   - Repeat for all 12 tabs

6. **Orchestrators run**
   - Each generates scaffolds locally
   - Spawns 10 agents
   - Agents create baskets
   - Orchestrator commits and pushes to recovery branch

7. **Progress monitoring**
   ```javascript
   GET /recovery/status/cmn_for_eng
   ```

8. **Completion**
   - All 243 seeds filled
   - Recovery branches visible on GitHub
   - Extract baskets with existing extraction script

---

## Scalability

### Fixed vs Variable

| Parameter | Value | Type |
|-----------|-------|------|
| Windows | 12 | **Fixed** (Safari tab limit) |
| Agents per window | 10 | **Fixed** (proven stable) |
| Seeds per agent | Calculated | **Variable** (adapts to missing count) |

### Examples

| Missing Seeds | Seeds/Agent | Total Capacity |
|--------------|-------------|----------------|
| 40 seeds | 1 | 120 |
| 120 seeds | 1 | 120 |
| 243 seeds | 3 | 360 |
| 600 seeds | 5 | 600 |

**Formula:**
```
seeds_per_agent = ceil(missing_seeds / 12 / 10)
```

---

## Use Cases

### 1. After Rate Limit Failures

Most common scenario. Many agents hit API limits and freeze.

```bash
# Via API
curl -X POST http://localhost:3459/recovery \
  -d '{"courseCode": "cmn_for_eng"}'

# Or standalone
node services/phase5_recovery_orchestrator.cjs cmn_for_eng
```

### 2. Quality Issues Requiring Regeneration

Specific seeds need to be regenerated due to quality problems.

**Option A:** Manual deletion + recovery
```bash
# Delete bad baskets from lego_baskets.json
# Then run recovery
POST /recovery
```

**Option B:** Use /regenerate endpoint (for specific LEGOs)
```bash
POST /regenerate
{
  "courseCode": "cmn_for_eng",
  "legoIds": ["S0115L01", "S0115L02"],
  "target": "Chinese",
  "known": "English"
}
```

### 3. New 668-Seed Course

For a brand new course, recovery system can handle initial generation too.

```bash
# Start with 668 missing seeds
node services/phase5_recovery_orchestrator.cjs fra_for_eng
# Generates all baskets using same 12-window approach
```

---

## Integration with Existing System

### Phase 5 Server Endpoints

| Endpoint | Purpose | When to Use |
|----------|---------|-------------|
| `POST /start` | Full Phase 5 run | New course, automated pipeline |
| `POST /recovery` | Gap filling | After failures, partial recovery |
| `POST /regenerate` | Specific LEGO fixes | Quality issues with specific LEGOs |
| `GET /status/:courseCode` | Check full run progress | Monitor /start jobs |
| `GET /recovery/status/:courseCode` | Check recovery progress | Monitor /recovery jobs |

---

## Monitoring

### Logs

Phase 5 server logs show recovery progress:
```
[Phase 5] ====================================
[Phase 5] BASKET RECOVERY MODE
[Phase 5] ====================================
[Phase 5] Course: cmn_for_eng
[Phase 5] Auto-launch Safari: true
[Phase 5] Found 243 missing seeds
[Phase 5] Recovery strategy: 12 windows × 10 agents × 3 seeds
[Phase 5] Generated 12 orchestrator prompts
[Phase 5] ✅ Safari tabs launched
```

### GitHub

Watch for recovery branches:
```bash
git fetch --all
git branch -r | grep recovery
```

Branches follow pattern:
```
baskets-{courseCode}-recovery-w{windowNum}-{sessionId}
```

Example:
```
baskets-cmn_for_eng-recovery-w01-01ABC123XYZ
baskets-cmn_for_eng-recovery-w02-01DEF456UVW
...
```

---

## Troubleshooting

### Recovery not detecting gaps

**Check:**
1. GitHub branches exist: `git branch -r | grep baskets`
2. Basket files have correct naming: `seed_S0115_baskets.json` (uppercase S)
3. Course code matches: exactly `cmn_for_eng` not `CMN_for_eng`

**Fix:**
```bash
# Manual gap detection
node scripts/detect_missing_baskets.cjs cmn_for_eng
cat missing_seeds.json
```

### Safari tabs don't launch

**Check:**
1. osascript permissions (macOS System Preferences → Security)
2. Safari is default browser

**Fix:**
```bash
# Launch manually
./scripts/launch_phase5_recovery.sh cmn_for_eng
```

### Prompts not generating

**Check:**
1. `missing_seeds.json` exists
2. Scripts are executable

**Fix:**
```bash
chmod +x scripts/*.cjs
node scripts/generate_recovery_prompts.cjs cmn_for_eng
```

---

## Future Enhancements

### Potential Additions

1. **Auto-extraction after recovery**
   - Watch for recovery branches
   - Auto-extract when all complete
   - Merge into `lego_baskets.json`

2. **Dashboard UI integration**
   - "Recover Missing" button in UI
   - Real-time progress bar
   - Show missing seed ranges

3. **Slack notifications**
   - Alert when recovery completes
   - Show before/after stats

4. **Retry failed agents**
   - Detect which agents failed
   - Auto-retry just those seeds

5. **Validation gates**
   - Auto-validate recovered baskets
   - Block merge if quality issues

---

## Summary

The Phase 5 Recovery System is now a **first-class citizen** in the automation architecture:

✅ Integrated into Phase 5 server (port 3459)
✅ RESTful API endpoints
✅ Standalone CLI tools
✅ Configured in automation.config.json
✅ Scalable (12 windows × 10 agents × variable seeds)
✅ Reusable across all 668-seed courses

**One command recovery:**
```bash
curl -X POST http://localhost:3459/recovery -d '{"courseCode": "cmn_for_eng"}'
```

Or standalone:
```bash
node services/phase5_recovery_orchestrator.cjs cmn_for_eng
```

Ready for production use! 🎉
