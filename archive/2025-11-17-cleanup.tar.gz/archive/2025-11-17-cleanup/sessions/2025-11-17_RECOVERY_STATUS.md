# Chinese Baskets Recovery Status

## Summary
- **Total seeds extracted:** 356 unique seed files
- **Total baskets:** 1,410 baskets in consolidated file
- **Consolidated file:** `public/vfs/courses/cmn_for_eng/lego_baskets.json` (2.3 MB)
- **Source:** 112 GitHub branches (successful pushes only)

## Seeds Successfully Recovered
Successfully extracted from GitHub branches that completed their push:

S0001-S0042 (42 seeds)
S0073-S0084 (12 seeds)
S0088-S0102 (15 seeds)
S0109-S0114 (6 seeds)
S0118-S0120 (3 seeds)
S0124-S0132 (9 seeds)
S0193-S0225 (33 seeds)
S0232-S0234 (3 seeds)
S0250-S0321 (72 seeds)
S0325-S0342 (18 seeds)
S0433-S0480 (48 seeds)
S0484-S0495 (12 seeds)
S0508-S0519 (12 seeds)
S0523-S0531 (9 seeds)
S0541-S0543 (3 seeds)
S0547-S0549 (3 seeds)
S0553-S0555 (3 seeds)
S0559-S0612 (54 seeds)

**Total:** 356 seeds

## Potential Gaps (Failed Branch Pushes)

Based on the GitHub deployment failures, these seeds may have been generated but failed to push:

### Failed Branches (from screenshot):
1. `claude/baskets-cmn_for_eng-window-6-s...` - Error after 15s
2. `claude/baskets-cmn_for_eng-window-3-s...` - Error after 1m 12s
3. `claude/spawn-phase5-agents-014wz6YMkn...` - Error after 31s

### Likely Missing Ranges:
- S0043-S0072 (30 seeds) - Gap between S0042 and S0073
- S0085-S0087 (3 seeds) - Small gap
- S0103-S0108 (6 seeds) - Small gap
- S0115-S0117 (3 seeds) - Small gap
- S0121-S0123 (3 seeds) - Small gap
- S0133-S0192 (60 seeds) - Large gap
- S0226-S0231 (6 seeds) - Small gap
- S0235-S0249 (15 seeds) - Medium gap
- S0322-S0324 (3 seeds) - Small gap
- S0343-S0432 (90 seeds) - Large gap
- S0481-S0483 (3 seeds) - Small gap
- S0496-S0507 (12 seeds) - Medium gap
- S0520-S0522 (3 seeds) - Small gap
- S0532-S0540 (9 seeds) - Small gap
- S0544-S0546 (3 seeds) - Small gap
- S0550-S0552 (3 seeds) - Small gap
- S0556-S0558 (3 seeds) - Small gap

**Total gaps:** ~256 seeds potentially need manual recovery

## Next Steps

### Option A: Manual Recovery from Browser Sessions
If the Claude Code web sessions are still open:
1. Check each browser tab for completed basket generation
2. Look for phase5_outputs directory with seed files
3. Download missing seed_SXXXX_baskets.json files
4. Run consolidation script again to merge

### Option B: Re-generate Missing Seeds
If browser sessions are closed or data is lost:
1. Identify which LEGO pairs correspond to missing seeds
2. Re-run phase 5 basket generation for those seeds
3. Merge into consolidated file

### Option C: Accept Current Coverage
- We have 356/612 seeds = **58% coverage**
- 1,410 baskets already consolidated
- This may be sufficient for initial deployment

## Files
- **Consolidated:** `public/vfs/courses/cmn_for_eng/lego_baskets.json`
- **Individual files:** `public/vfs/courses/cmn_for_eng/phase5_outputs/seed_S*_baskets.json` (356 files)
- **Extraction script:** `extract_all_baskets.sh`
- **Consolidation script:** `consolidate_cmn_baskets.cjs`
