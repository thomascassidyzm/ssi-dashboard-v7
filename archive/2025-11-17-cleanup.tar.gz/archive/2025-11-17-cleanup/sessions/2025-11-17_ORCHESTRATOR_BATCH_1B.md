# Orchestrator Prompt - Batch 1B (Tab 2)

**Course**: cmn_for_eng
**Seeds to Process**: S0373-S0402 (30 seeds)
**Strategy**: 6 mini-batches of 5 agents each

---

## Your Task

You are orchestrating Phase 5 LEGO basket generation for Chinese language course. Process seeds S0373 through S0402 using a controlled batching approach.

### Repository Setup
```bash
git clone https://github.com/zenjin/ssi-dashboard-v7-clean.git
cd ssi-dashboard-v7-clean
```

### Execution Plan

**IMPORTANT**: Wait 2 minutes after starting Tab 1 before beginning, to stagger load.

Process seeds in **6 mini-batches of 5 seeds each**. After each mini-batch completes, push to GitHub before starting the next.

#### Mini-Batch 1: S0373-S0377
Spawn 5 agents in parallel, each generating 1 seed:
- Agent 1: S0373
- Agent 2: S0374
- Agent 3: S0375
- Agent 4: S0376
- Agent 5: S0377

Wait for all 5 to complete. Then push:
```bash
git add public/vfs/courses/cmn_for_eng/phase5_outputs/seed_S037[3-7]_baskets.json
git commit -m "Phase 5 baskets: S0373-S0377"
git push origin HEAD:baskets-cmn_for_eng-batch1b-mb1
```

#### Mini-Batch 2: S0378-S0382
Process S0378-S0382, push to `baskets-cmn_for_eng-batch1b-mb2`

#### Mini-Batch 3: S0383-S0387
Process S0383-S0387, push to `baskets-cmn_for_eng-batch1b-mb3`

#### Mini-Batch 4: S0388-S0392
Process S0388-S0392, push to `baskets-cmn_for_eng-batch1b-mb4`

#### Mini-Batch 5: S0393-S0397
Process S0393-S0397, push to `baskets-cmn_for_eng-batch1b-mb5`

#### Mini-Batch 6: S0398-S0402
Process S0398-S0402, push to `baskets-cmn_for_eng-batch1b-mb6`

### Agent Instructions Template

Each agent should receive this prompt:

```
Generate Phase 5 LEGO basket data for seed S0XXX in the cmn_for_eng course.

1. Read the seed data from public/vfs/courses/cmn_for_eng/seedsJSON/seed_S0XXX.json
2. Generate practice phrases following the Phase 5 LEGO basket format
3. Save to public/vfs/courses/cmn_for_eng/phase5_outputs/seed_S0XXX_baskets.json

Use the existing basket files as reference for the correct format.
```

### Success Criteria
- ✅ All 30 basket files generated
- ✅ 6 successful GitHub pushes
- ✅ No rate limit errors
- ✅ Files visible in GitHub branches

### Important Notes
- **Wait 2 minutes** after Tab 1 starts before beginning
- **Wait** for each mini-batch to complete before starting next
- **Don't spawn all 30 at once** - this causes rate limits
- Report progress after each mini-batch
