# Batch Re-Run Strategy for Missing Seeds

## Overview
Re-running 265 missing seeds using controlled batching to avoid rate limits.

## Rate Limit Lessons Learned
- ❌ **Previous attempt**: 24 tabs × 10 parallel agents = 240 concurrent sessions
- ✅ **New strategy**: 3 tabs × sequential batches = ~10-15 concurrent max

## Three-Batch Approach

### Batch 1: Large Gap Priority (90 seeds)
**Seeds**: S0343-S0432
**Tabs**: Use 3 orchestrator tabs
**Distribution**: 30 seeds per tab

### Batch 2: Medium Gaps (85 seeds)
**Seeds**: S0133-S0192 (60) + S0226-S0249 (24)
**Tabs**: Use 3 orchestrator tabs
**Distribution**: ~28-30 seeds per tab

### Batch 3: Remaining Small Gaps (90 seeds)
**Seeds**: All remaining ranges from missing_seeds.txt
**Tabs**: Use 3 orchestrator tabs
**Distribution**: 30 seeds per tab

## Execution Strategy Per Tab

Each orchestrator tab will:
1. Process seeds in batches of 5 agents at a time
2. Wait for completion before spawning next batch
3. Each agent handles 1-2 seeds
4. Push to GitHub after each mini-batch completes

This keeps concurrent sessions at ~15 maximum (3 tabs × 5 agents)

## Safety Features

- **Sequential mini-batches** within each tab (not all 30 at once)
- **Staggered start times** across the 3 tabs (start Tab 2 after Tab 1 spawns first batch)
- **GitHub push after every 5 agents** (smaller atomic commits)
- **Session monitoring** between batches

## Monitoring

Use the watch_for_pushes.sh script (already running) to:
- Track branches as they arrive
- Auto-extract basket files
- Update progress count

## Post-Batch Consolidation

After all batches complete:
1. Run `node consolidate_cmn_baskets.cjs` to merge new files
2. Verify all 612 seeds are present
3. Commit final lego_baskets.json
4. Clean up branch clutter

---

**Estimated Timeline**:
- Batch 1: ~45 minutes
- Batch 2: ~40 minutes
- Batch 3: ~45 minutes
- **Total**: ~2 hours (vs overnight + recovery attempts)
