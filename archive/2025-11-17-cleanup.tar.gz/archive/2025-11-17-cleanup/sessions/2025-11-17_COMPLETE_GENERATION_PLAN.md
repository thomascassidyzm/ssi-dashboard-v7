# Complete Phase 5 Basket Generation Plan

## Current Status
- **Total seeds needed**: 668 (S0001-S0668)
- **Seeds we have**: 347
- **Seeds missing**: 321
- **Success rate so far**: 52%

## Missing Seeds by Priority

### Tier 1: Large Gaps (236 seeds total)
1. **S0343-S0432** - 90 seeds (largest gap)
2. **S0133-S0192** - 60 seeds
3. **S0613-S0668** - 56 seeds (end of course)
4. **S0043-S0072** - 30 seeds

### Tier 2: Medium Gaps (36 seeds total)
5. **S0226-S0249** - 24 seeds
6. **S0496-S0507** - 12 seeds

### Tier 3: Small Gaps (49 seeds total)
7. **S0532-S0540** - 9 seeds
8. **S0103-S0108** - 6 seeds
9. Plus 18 gaps of 3 seeds each
10. Plus 1 gap of 1 seed (S0451)

---

## Recommended Batching Strategy

### **Option A: Conservative (Recommended)**
**3 orchestrator sessions × 3 waves = 9 total runs**

Better parallelization control, lower risk of rate limits

#### Session 1: Large Gaps Part 1 (90 seeds)
- **Wave 1**: S0343-S0372 (30 seeds) - 6 mini-batches of 5
- **Wave 2**: S0373-S0402 (30 seeds) - 6 mini-batches of 5
- **Wave 3**: S0403-S0432 (30 seeds) - 6 mini-batches of 5
- **Duration**: ~45 minutes
- **Concurrency**: 5 agents per wave (15 total)

#### Session 2: Large Gaps Part 2 (86 seeds)
- **Wave 1**: S0133-S0162 (30 seeds) - 6 mini-batches of 5
- **Wave 2**: S0163-S0192 (30 seeds) - 6 mini-batches of 5
- **Wave 3**: S0043-S0068 (26 seeds) - 6 mini-batches of 4-5
- **Duration**: ~45 minutes
- **Concurrency**: 5 agents per wave (15 total)

#### Session 3: Large Gaps Part 3 (60 seeds)
- **Wave 1**: S0613-S0638 (26 seeds) - 6 mini-batches of 4-5
- **Wave 2**: S0639-S0668 (30 seeds) - 6 mini-batches of 5
- **Wave 3**: S0069-S0072 + S0226-S0249 (28 seeds) - Mixed cleanup
- **Duration**: ~45 minutes
- **Concurrency**: 5 agents per wave (15 total)

#### Session 4: Medium + Small Gaps (85 seeds)
- **Wave 1**: All 3-seed gaps batch 1 (30 seeds) - 6 mini-batches of 5
- **Wave 2**: All 3-seed gaps batch 2 (19 seeds) - 4 mini-batches of 4-5
- **Wave 3**: Remaining small gaps (36 seeds) - 7 mini-batches of 5
- **Duration**: ~45 minutes
- **Concurrency**: 5 agents per wave (15 total)

**Total time: ~3 hours**

---

### **Option B: Aggressive**
**6 orchestrator sessions × 2 waves = 12 total runs**

Faster completion but higher risk

- More concurrent tabs (up to 6)
- Each tab runs 2 waves sequentially
- Completes in ~2 hours but may hit rate limits
- **Not recommended** based on previous experience

---

## Implementation Per Wave

Each wave follows this pattern:

```
1. Clone repo / ensure clean state
2. Spawn 5 agents in parallel (each handles 1 seed)
3. Wait for all 5 to complete
4. Git add + commit + push to unique branch
5. Repeat for next mini-batch
6. After 6 mini-batches (30 seeds), wave complete
```

### Git Branch Naming
```
session1-wave1-mb1  (S0343-S0347)
session1-wave1-mb2  (S0348-S0352)
...
session4-wave3-mb7  (final batch)
```

### Success Criteria
- ✅ All 321 basket files generated
- ✅ All pushed to GitHub successfully
- ✅ Watch script confirms extraction
- ✅ No rate limit errors
- ✅ Total seed count reaches 668

---

## Monitoring & Safety

### Auto-Monitoring
The `watch_for_pushes.sh` script (already running) will:
- Detect new branches every 10 seconds
- Auto-extract basket files
- Report running totals

### Manual Checkpoints
After each session completes, verify:
```bash
ls public/vfs/courses/cmn_for_eng/phase5_outputs/seed_S*_baskets.json | wc -l
```

Expected progression:
- After Session 1: 347 + 90 = 437 seeds
- After Session 2: 437 + 86 = 523 seeds
- After Session 3: 523 + 60 = 583 seeds
- After Session 4: 583 + 85 = 668 seeds ✅

### If Rate Limits Hit
- Stop spawning new agents
- Let current agents finish
- Wait for limit to reset (shown in error message)
- Resume with next session

---

## Final Consolidation

After all 668 seeds are collected:

```bash
node consolidate_cmn_baskets.cjs
```

This will:
1. Read all 668 individual seed basket files
2. Merge into single `lego_baskets.json`
3. Update metadata (total seeds, total baskets)
4. Report final statistics

Then commit the final consolidated file:
```bash
git add public/vfs/courses/cmn_for_eng/lego_baskets.json
git commit -m "Complete Phase 5 baskets: all 668 seeds consolidated"
git push origin main
```

---

## Recommended Execution Order

**Today (Session 1)**: S0343-S0432 (90 seeds)
- Tackles the largest gap
- Validates the batching strategy works
- ~45 minutes

**Tomorrow or later today (Session 2)**: S0133-S0192 + S0043-S0068 (86 seeds)
- Second and fourth largest gaps
- Another ~45 minutes

**Session 3**: S0613-S0668 + cleanup (60 seeds)
- Completes the end of the course
- ~45 minutes

**Session 4**: All remaining small gaps (85 seeds)
- Cleanup all the 3-seed and 1-seed gaps
- ~45 minutes

**TOTAL**: ~3 hours of generation time (can be spread over multiple days)
