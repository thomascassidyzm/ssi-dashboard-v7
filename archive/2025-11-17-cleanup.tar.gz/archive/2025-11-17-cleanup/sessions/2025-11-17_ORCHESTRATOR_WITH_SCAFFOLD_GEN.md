# Orchestrator Template with Scaffold Generation

## The Solution

Instead of pushing 8.2MB of scaffolds to GitHub, **each orchestrator generates its own scaffolds** for just the seeds it needs. This is:

- ✅ **Fast** - Scaffold generation is instant
- ✅ **Lightweight** - No large files in git
- ✅ **Self-contained** - Each orchestrator has exactly what it needs
- ✅ **Scales** - Works for any number of seeds

---

## Orchestrator Template

```markdown
# Phase 5 Basket Generation - Orchestrator {NUM}

**Seeds to Process**: {START_SEED}-{END_SEED} ({COUNT} seeds)
**Session ID**: {SESSION_ID}
**Branch Name**: baskets-cmn_for_eng-{START_SEED}-{END_SEED}-{SESSION_ID}

## Step 1: Clone Repository

```bash
git clone https://github.com/zenjin/ssi-dashboard-v7-clean.git
cd ssi-dashboard-v7-clean
git checkout -b baskets-cmn_for_eng-{START_SEED}-{END_SEED}-{SESSION_ID}
```

## Step 2: Generate Scaffolds for Your Seeds

Run this script to create scaffolds for seeds {START_NUM}-{END_NUM}:

```bash
node << 'SCAFFOLD_GEN'
const fs = require('fs');

// Read lego_pairs.json
const legoPairs = JSON.parse(fs.readFileSync('public/vfs/courses/cmn_for_eng/lego_pairs.json', 'utf8'));

// Create scaffolds directory
fs.mkdirSync('public/vfs/courses/cmn_for_eng/phase5_scaffolds', { recursive: true });

// Generate scaffolds for seeds {START_NUM} to {END_NUM}
for (let seedNum = {START_NUM}; seedNum <= {END_NUM}; seedNum++) {
  const seedId = `S${String(seedNum).padStart(4, '0')}`;

  // Find this seed in lego_pairs
  const seedData = legoPairs.seeds.find(s => s.seed_id === seedId);

  if (!seedData) {
    console.log(`Warning: ${seedId} not found in lego_pairs.json`);
    continue;
  }

  // Create scaffold with just the LEGOs that have new:true
  const scaffold = {
    seed_id: seedId,
    legos: seedData.legos.filter(lego => lego.new === true)
  };

  // Write scaffold file (lowercase s, no suffix)
  const filename = `public/vfs/courses/cmn_for_eng/phase5_scaffolds/seed_s${String(seedNum).padStart(4, '0')}.json`;
  fs.writeFileSync(filename, JSON.stringify(scaffold, null, 2));
  console.log(`Created: ${filename}`);
}

console.log('\\nScaffolds generated successfully!');
SCAFFOLD_GEN
```

This creates scaffolds ONLY for your assigned seeds (not all 668).

## Step 3: Process Seeds in Mini-Batches

Now spawn agents to generate baskets. Each agent reads from the scaffolds you just created.

### Mini-Batch Pattern (5 seeds per batch)

For each mini-batch of 5 seeds:

#### A. Spawn 5 Agents

Use Task tool to spawn 5 agents in parallel. Give each agent this instruction:

```
Generate Phase 5 LEGO basket for seed {SEED_ID}.

Files:
- Read scaffold: public/vfs/courses/cmn_for_eng/phase5_scaffolds/seed_s{NUM}.json
- Write basket: public/vfs/courses/cmn_for_eng/phase5_outputs/seed_{SEED_ID}_baskets.json

Example for S0115:
- Read: public/vfs/courses/cmn_for_eng/phase5_scaffolds/seed_s0115.json
- Write: public/vfs/courses/cmn_for_eng/phase5_outputs/seed_S0115_baskets.json

Steps:
1. Read the scaffold file
2. Extract LEGOs and metadata
3. Generate practice phrases (10 per LEGO)
4. Save to basket file

DO NOT do git operations - orchestrator handles that.
```

#### B. Wait for Completion

Wait for all 5 agents to finish.

#### C. Commit and Push

```bash
# Add the new basket files
git add public/vfs/courses/cmn_for_eng/phase5_outputs/seed_S*.json

# Commit
git commit -m "Mini-batch X: Seeds {SEED_START}-{SEED_END}"

# Push to your branch
git push origin baskets-cmn_for_eng-{START_SEED}-{END_SEED}-{SESSION_ID}
```

#### D. Report Progress

```
✅ Mini-batch X complete: {SEED_START}-{SEED_END}
```

Repeat for all mini-batches.

## Step 4: Final Verification

After all mini-batches complete:

```bash
# Count generated baskets
count=$(ls public/vfs/courses/cmn_for_eng/phase5_outputs/seed_S*.json | wc -l)
echo "Generated: $count / {COUNT} baskets"

# Verify your specific seeds are present
ls public/vfs/courses/cmn_for_eng/phase5_outputs/seed_S0{START_NUM..END_NUM}_baskets.json

# If all present, report success
echo "✅ All {COUNT} seeds complete!"
```

---

## Example: Orchestrator for S0115-S0164 (50 seeds)

```markdown
# Phase 5 Basket Generation - Orchestrator 1

**Seeds**: S0115-S0164 (50 seeds)
**Session ID**: 01ABC123XYZ
**Branch**: baskets-cmn_for_eng-S0115-S0164-01ABC123XYZ

## Step 1: Clone

```bash
git clone https://github.com/zenjin/ssi-dashboard-v7-clean.git
cd ssi-dashboard-v7-clean
git checkout -b baskets-cmn_for_eng-S0115-S0164-01ABC123XYZ
```

## Step 2: Generate Scaffolds

```bash
node << 'SCAFFOLD_GEN'
const fs = require('fs');
const legoPairs = JSON.parse(fs.readFileSync('public/vfs/courses/cmn_for_eng/lego_pairs.json', 'utf8'));
fs.mkdirSync('public/vfs/courses/cmn_for_eng/phase5_scaffolds', { recursive: true });

for (let seedNum = 115; seedNum <= 164; seedNum++) {
  const seedId = `S${String(seedNum).padStart(4, '0')}`;
  const seedData = legoPairs.seeds.find(s => s.seed_id === seedId);

  if (!seedData) {
    console.log(`Warning: ${seedId} not found`);
    continue;
  }

  const scaffold = {
    seed_id: seedId,
    legos: seedData.legos.filter(lego => lego.new === true)
  };

  const filename = `public/vfs/courses/cmn_for_eng/phase5_scaffolds/seed_s${String(seedNum).padStart(4, '0')}.json`;
  fs.writeFileSync(filename, JSON.stringify(scaffold, null, 2));
}

console.log('Scaffolds for S0115-S0164 created!');
SCAFFOLD_GEN
```

## Step 3: Process in 10 Mini-Batches of 5 Seeds

Mini-batch 1: S0115-S0119
Mini-batch 2: S0120-S0124
...
Mini-batch 10: S0160-S0164

For each batch: spawn 5 agents → wait → commit → push

## Step 4: Verify

```bash
ls public/vfs/courses/cmn_for_eng/phase5_outputs/seed_S0{115..164}_baskets.json | wc -l
# Should show: 50
```
```

---

## Benefits of This Approach

| Aspect | Scaffold in Git (Old) | Generate Locally (New) |
|--------|----------------------|------------------------|
| Git repo size | +8.2MB | No change |
| Push time | Minutes (fails) | Seconds |
| Orchestrator setup | git clone | git clone + 1 script |
| Scalability | All 668 always | Only what you need |
| Flexibility | Fixed | Can regenerate anytime |

---

## Scaffold Generation Script Explanation

```javascript
// This script:
// 1. Reads lego_pairs.json (already in git, ~1.4MB)
// 2. Filters to just your assigned seeds
// 3. Extracts only LEGOs with new:true
// 4. Writes scaffold files locally
// 5. Takes ~1 second for 50 seeds

// Scaffold format:
{
  "seed_id": "S0115",
  "legos": [
    {
      "id": "S0115L01",
      "type": "A",
      "target": "很",
      "known": "very",
      "new": true
    },
    // ... more LEGOs
  ]
}

// Agents read this to know which LEGOs to create baskets for
```

---

## For Next Run

When creating orchestrator prompts, replace:
- `{NUM}` → Orchestrator number (1-10)
- `{START_SEED}` → First seed (e.g., S0115)
- `{END_SEED}` → Last seed (e.g., S0164)
- `{COUNT}` → Number of seeds (e.g., 50)
- `{START_NUM}` → First seed number (e.g., 115)
- `{END_NUM}` → Last seed number (e.g., 164)
- `{SESSION_ID}` → Orchestrator's Claude Code session ID

The orchestrator will:
1. Clone repo (pulls lego_pairs.json)
2. Generate scaffolds locally (1 second)
3. Spawn agents to create baskets
4. Push just the basket files

**Result**: Clean, fast, scalable! 🎯
