# Lessons Learned: Phase 5 Basket Generation

## Session ID Authentication Issue

### Problem
When orchestrator spawns sub-agents, each sub-agent gets its own session ID. When they try to push to GitHub, the branch names must end with the **orchestrator's session ID**, not the sub-agent's session ID.

### Symptom
```
HTTP 403 Forbidden
Authentication failed
```

### Root Cause
GitHub authentication in Claude Code validates that the branch name ends with the active session ID. Sub-agents were creating branches like:
```
claude/baskets-cmn_for_eng-window-1-s0013-s0015-<SUB_AGENT_SESSION_ID>
```

But the orchestrator session ID was different, causing authentication to fail.

### Solution
Branch names must use the **orchestrator's session ID**:
```
claude/baskets-cmn_for_eng-window-1-s0013-s0015-<ORCHESTRATOR_SESSION_ID>
```

### Fix Applied
After generation, rename all branches before pushing:
```bash
# Get orchestrator session ID
ORCH_SESSION="01CYnKiqbHhrYNxYCGToMw7h"

# Rename each branch
git branch -m old-branch-name new-branch-with-orch-session-id

# Then push succeeds
git push origin HEAD:claude/baskets-cmn_for_eng-window-1-s0013-s0015-$ORCH_SESSION
```

### Prevention for Future Runs

#### Option 1: Pass Session ID to Sub-Agents
In orchestrator prompt, explicitly pass the session ID:
```
ORCHESTRATOR_SESSION="<your-session-id-here>"

For each agent, pass this instruction:
"When creating git branches, always suffix with: $ORCHESTRATOR_SESSION"
```

#### Option 2: Use Simplified Branch Names
Don't include session IDs in branch names at all:
```
git push origin HEAD:claude/baskets-cmn_for_eng-window-1-s0013-s0015
```
(May require testing if this works)

#### Option 3: Push from Orchestrator Level
Instead of each sub-agent pushing, have them commit locally and let the orchestrator collect and push:
```
1. Sub-agents: git add + git commit (local only)
2. Orchestrator: git push origin HEAD:<branch-with-orch-session>
```

---

## Rate Limit Insights

### What Worked
- **Sequential mini-batches** within each orchestrator
- **Staggered start times** across multiple orchestrator tabs
- **3-5 agents per mini-batch** (not 10 at once)

### What Failed
- **240 concurrent sessions** (24 tabs × 10 agents)
- **Spawning all 10 agents simultaneously** per orchestrator
- **No delays between spawns**

### Recommended Approach
```
✅ 10 orchestrator tabs maximum
✅ Each spawns 3-5 agents at a time (mini-batches)
✅ Wait for mini-batch completion before next spawn
✅ Total concurrent: 30-50 agents (not 240)
✅ Stagger orchestrator starts by 1-2 minutes
```

---

## Git Repository Size Issues

### Problem
Tracking 356+ basket files in git caused:
- Massive repository bloat (112 branches × 356 files)
- Vercel deployment timeouts (504 Gateway Timeout)
- Slow git operations

### Solution
1. **Consolidate** into single `lego_baskets.json`
2. **Update .gitignore** to exclude individual basket files
3. **Use .vercelignore** to exclude VFS data from deployment

### Correct .gitignore Pattern
```
# Exclude individual basket files
public/vfs/courses/*/phase5_outputs/*_baskets.json

# Keep consolidated file
!public/vfs/courses/*/lego_baskets.json
```

---

## Orchestrator Prompt Improvements

### Key Instructions to Include

1. **Session ID Handling**
```
IMPORTANT: All git branches must end with this session ID: <ORCHESTRATOR_SESSION_ID>

When pushing, use:
git push origin HEAD:claude/baskets-cmn_for_eng-<description>-<ORCHESTRATOR_SESSION_ID>
```

2. **Mini-Batch Execution**
```
DO NOT spawn all agents at once!

Instead, use mini-batches:
- Spawn 3-5 agents in parallel
- Wait for ALL to complete
- Push results to GitHub
- Then spawn next mini-batch
```

3. **Error Recovery**
```
If git push fails with 403:
1. Check branch name ends with session ID: <ORCHESTRATOR_SESSION_ID>
2. Rename branch if needed: git branch -m <new-name>
3. Retry push
```

---

## Recovery Statistics

### Original Run (Overnight)
- **Attempted**: 321 missing seeds via 240 concurrent sessions
- **Succeeded initially**: 0 (all frozen/rate-limited)
- **Recovered after unfreezing**: 59 seeds
- **Final recovery rate**: 18%

### Lessons
- Rate limits cause sessions to freeze, not fail gracefully
- Frozen sessions can be "revived" hours later
- Session limit resets are time-based (not per-request)
- Better to run slower with guaranteed success than fast with failures

---

## Recommended Orchestrator Template

```markdown
# Phase 5 Basket Generation - Window X

**Session ID**: <ORCHESTRATOR_SESSION_ID>
**Seeds to Process**: S0XXX-S0YYY (NN seeds)

## Setup
git clone https://github.com/user/repo.git
cd repo

## Execution Strategy
Process seeds in mini-batches of 3-5 agents:

### Mini-Batch 1: S0XXX-S0XXX+4
Spawn 5 agents in parallel:
- Agent 1: S0XXX
- Agent 2: S0XXX+1
- Agent 3: S0XXX+2
- Agent 4: S0XXX+3
- Agent 5: S0XXX+4

Wait for all to complete.

Push to GitHub:
```bash
git add public/vfs/courses/cmn_for_eng/phase5_outputs/seed_S0XXX*_baskets.json
git commit -m "Phase 5 baskets: S0XXX-S0XXX+4"
git push origin HEAD:claude/baskets-cmn_for_eng-windowX-mb1-<ORCHESTRATOR_SESSION_ID>
```

### Mini-Batch 2: S0XXX+5-S0XXX+9
[Repeat pattern...]

## CRITICAL: Branch Naming
ALL branches must end with: <ORCHESTRATOR_SESSION_ID>

If push fails with 403, check session ID in branch name!
```

---

## Next Steps for Production Use

1. **Create reusable orchestrator template** with session ID handling
2. **Test simplified branch naming** (without session IDs)
3. **Implement orchestrator-level pushing** instead of sub-agent pushing
4. **Add automatic session ID detection** in prompts
5. **Document rate limit thresholds** (appears to be ~50 concurrent sessions)
