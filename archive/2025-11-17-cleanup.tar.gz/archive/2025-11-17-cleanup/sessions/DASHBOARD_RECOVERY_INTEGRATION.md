# Dashboard Recovery Integration - Complete

## What Was Built

The Phase 5 Recovery System is now **fully integrated** into the SSi Dashboard UI, allowing one-click recovery of missing baskets from the browser.

---

## User Flow

### Step 1: Open Course in Dashboard

Navigate to: `https://ssi-dashboard-v7.vercel.app/courses/cmn_for_eng`

### Step 2: Click "Validate & Fix"

Opens the Quality Control panel with 4 sections:
1. LUT Check (Phase 3.6)
2. Infinitive Check
3. **Basket Gap Analysis** ← Recovery starts here
4. **Recover Missing Baskets** ← One-click orchestration

### Step 3: Analyze Gaps

Click **"📊 Analyze Gaps"**

**What it does:**
- Calls `GET /api/courses/:courseCode/baskets/recovery/status`
- Orchestrator → Phase 5 Server → `detect_missing_baskets.cjs`
- Analyzes GitHub branches for missing seeds
- Shows results in UI:
  ```
  Found on GitHub: 425
  Missing Seeds: 243
  Completion: 63.6%
  ```

### Step 4: Start Recovery

Click **"🚀 Start Recovery"**

**Confirmation dialog shows:**
```
Recovery will launch 12 Safari tabs with Claude Code orchestrators.

Missing seeds: 243
Strategy: 12 windows × 10 agents × ~3 seeds
Estimated time: 3-5 hours

Continue?
```

**What happens when you click OK:**
1. Dashboard calls `POST /api/courses/:courseCode/baskets/recovery`
2. Orchestrator proxies to Phase 5 Server `/recovery`
3. Phase 5 Recovery Orchestrator runs:
   - Generates 12 prompts in `.claude/recovery_prompts/`
   - Launches 12 Safari tabs with Claude Code
   - Each tab ready for its prompt
4. Dashboard shows success message:
   ```
   Recovery launched! 12 Safari tabs opened.

   Next steps:
   - Wait for Claude Code tabs to load
   - Paste corresponding prompt in each tab
   - Replace {SESSION_ID} with actual session ID
   - Monitor progress via GitHub branches
   ```

### Step 5: Paste Prompts

For each of the 12 tabs:
1. Copy prompt from `.claude/recovery_prompts/window_01.md`
2. Paste into Claude Code tab
3. Replace `{SESSION_ID}` with that tab's actual session ID
4. Let it run

### Step 6: Monitor Progress

Re-click **"Analyze Gaps"** periodically to see:
```
Found on GitHub: 550  ← increasing
Missing Seeds: 118    ← decreasing
Completion: 82.3%     ← improving
```

---

## Architecture Flow

```
┌─────────────────────────────────────────────────────────────┐
│  Dashboard UI (Vue Component: CourseEditor.vue)             │
│  - Click "Analyze Gaps" button                              │
│  - Click "Start Recovery" button                            │
└──────────────────────┬──────────────────────────────────────┘
                       │ HTTP
                       ▼
┌─────────────────────────────────────────────────────────────┐
│  Orchestrator (orchestrator.cjs - Port 3456)                │
│  GET  /api/courses/:courseCode/baskets/recovery/status      │
│  POST /api/courses/:courseCode/baskets/recovery             │
└──────────────────────┬──────────────────────────────────────┘
                       │ Proxy
                       ▼
┌─────────────────────────────────────────────────────────────┐
│  Phase 5 Basket Server (phase5-basket-server.cjs - 3459)    │
│  GET  /recovery/status/:courseCode                          │
│  POST /recovery                                             │
└──────────────────────┬──────────────────────────────────────┘
                       │ Requires
                       ▼
┌─────────────────────────────────────────────────────────────┐
│  Phase 5 Recovery Orchestrator                              │
│  (services/phase5_recovery_orchestrator.cjs)                │
│  - runRecovery()                                            │
│  - detectGaps()                                             │
│  - generatePrompts()                                        │
│  - launchBrowsers()                                         │
│  - checkStatus()                                            │
└──────────────────────┬──────────────────────────────────────┘
                       │ Uses
       ┌───────────────┼───────────────┐
       ▼               ▼               ▼
detect_missing_    generate_      Safari
baskets.cjs        recovery_      osascript
                   prompts.cjs
```

---

## Code Changes Summary

### 1. Orchestrator Endpoints Added

**File:** `services/orchestration/orchestrator.cjs`

**New endpoints:**
```javascript
POST /api/courses/:courseCode/baskets/recovery
GET  /api/courses/:courseCode/baskets/recovery/status
```

Both proxy to Phase 5 Server.

### 2. Vue Component Updated

**File:** `src/views/CourseEditor.vue`

**UI Changes:**
- "Basket Gap Analysis" now checks **GitHub** (not just local baskets)
- Shows "Found on GitHub", "Missing Seeds", "Completion %"
- "Regenerate Baskets" renamed to **"Recover Missing Baskets"**
- Button text: "Start Recovery" (instead of "Regenerate")

**Method Changes:**
- `runBasketGapAnalysis()` - Now calls `/recovery/status` endpoint
- `startRecovery()` - New method, replaces `regenerateBaskets()`
- Calls `/recovery` endpoint with confirmation dialog
- Shows recovery launch confirmation

### 3. Phase 5 Server Endpoints

**File:** `services/phases/phase5-basket-server.cjs`

**Endpoints already exist:**
```javascript
POST /recovery              // Trigger recovery
GET  /recovery/status/:courseCode  // Check progress
```

These were added in the integration phase.

---

## API Response Examples

### GET /recovery/status/cmn_for_eng

**Initial state (no recovery run yet):**
```json
{
  "status": "not_started",
  "message": "No recovery analysis found"
}
```

**After gap detection:**
```json
{
  "status": "in_progress",
  "initial_missing": 243,
  "current_missing": 243,
  "filled": 0,
  "progress": "0.0%",
  "remaining_seeds": [43, 44, 45, ...]
}
```

**During recovery:**
```json
{
  "status": "in_progress",
  "initial_missing": 243,
  "current_missing": 120,
  "filled": 123,
  "progress": "50.6%",
  "remaining_seeds": [133, 134, ...]
}
```

**Complete:**
```json
{
  "status": "complete",
  "initial_missing": 243,
  "current_missing": 0,
  "filled": 243,
  "progress": "100.0%",
  "remaining_seeds": []
}
```

### POST /recovery

**Request:**
```json
{
  "courseCode": "cmn_for_eng",
  "autoLaunch": true
}
```

**Response (Recovery Needed):**
```json
{
  "success": true,
  "recovery_initiated": true,
  "missing_seeds": 243,
  "recovery_params": {
    "num_windows": 12,
    "agents_per_window": 10,
    "seeds_per_agent": 3
  },
  "prompts": {
    "count": 12,
    "directory": ".claude/recovery_prompts",
    "files": ["window_01.md", "window_02.md", ...]
  },
  "next_steps": [
    "Wait for Claude Code tabs to load",
    "Paste corresponding prompt in each tab",
    "Replace {SESSION_ID} with actual session ID",
    "Monitor progress via GitHub branches"
  ]
}
```

**Response (No Recovery Needed):**
```json
{
  "success": true,
  "recovery_initiated": false,
  "message": "No missing baskets - all complete!"
}
```

---

## Testing the Integration

### Local Development

1. **Start automation servers:**
   ```bash
   pm2 list
   # Should show ssi-automation running
   ```

2. **Open dashboard:**
   ```
   https://ssi-dashboard-v7.vercel.app/courses/cmn_for_eng
   ```

3. **Test gap analysis:**
   - Click "Validate & Fix"
   - Click "Analyze Gaps"
   - Check DevTools Network tab for:
     ```
     GET http://localhost:3456/api/courses/cmn_for_eng/baskets/recovery/status
     ```

4. **Test recovery:**
   - Click "Start Recovery"
   - Confirm dialog
   - Check that 12 Safari tabs open
   - Check `.claude/recovery_prompts/` for generated files

### Production

Dashboard is deployed to Vercel. Just need to ensure:
1. Automation server is running locally (PM2)
2. ngrok tunnel is active (if needed for remote access)
3. Dashboard knows orchestrator URL via env var

---

## User Instructions (For Dashboard)

### Quick Start: Recover Missing Baskets

1. Go to course page
2. Click **"Validate & Fix"** button (top right)
3. Scroll to **"Basket Gap Analysis"** section
4. Click **"Analyze Gaps"**
   - Shows how many missing
5. Click **"Start Recovery"**
   - Confirms strategy
6. Click **OK** in confirmation dialog
7. **12 Safari tabs open** with Claude Code
8. For each tab:
   - Copy prompt from `.claude/recovery_prompts/window_XX.md`
   - Paste into Claude Code
   - Replace `{SESSION_ID}` with actual ID
   - Let it run
9. Monitor progress by clicking **"Analyze Gaps"** again

**That's it!** The recovery orchestrators handle everything else.

---

## Benefits

### Before Integration
- Manual detection: Count files, diff against expected
- Manual prompt generation: Copy/paste templates
- Manual Safari launch: Open tabs one by one
- Manual tracking: Check GitHub branches manually

### After Integration
- **One-click detection**: "Analyze Gaps" button
- **Auto prompt generation**: Happens in background
- **Auto Safari launch**: 12 tabs open automatically
- **Live progress**: Re-check anytime with "Analyze Gaps"

### Time Savings
- **Before:** ~30 minutes to set up recovery
- **After:** ~30 seconds (2 clicks + paste prompts)

---

## Future Enhancements

### Potential Additions

1. **Real-time progress bar**
   - Poll `/recovery/status` every 30 seconds
   - Show live completion percentage
   - Estimated time remaining

2. **Auto-refresh after recovery**
   - Detect when recovery complete
   - Auto-reload course data
   - Show "Recovery Complete!" banner

3. **Recovery history**
   - Show past recovery runs
   - Track success rate
   - Show which seeds were recovered when

4. **One-click "Finish & Extract"**
   - After recovery completes
   - Auto-extract baskets from recovery branches
   - Merge into `lego_baskets.json`

5. **Recovery scheduling**
   - Schedule recovery to run overnight
   - Email notification when done

---

## Summary

✅ Dashboard UI fully integrated with recovery system
✅ One-click gap detection (checks GitHub)
✅ One-click recovery launch (12 Safari tabs)
✅ Live progress monitoring
✅ Clean, user-friendly interface
✅ No manual scripts needed

**Recovery is now a first-class feature in the SSi Dashboard!** 🎉
