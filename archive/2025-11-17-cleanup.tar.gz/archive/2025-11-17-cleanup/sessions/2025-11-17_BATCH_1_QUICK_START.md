# Batch 1 Quick Start Guide

## What This Batch Does
Processes the **largest gap** in your missing seeds: S0343-S0432 (90 seeds total)

## Setup (Do This Once)

1. **Sign into your other Claude Code account** in the browser
2. **Open 3 new tabs** in Claude Code web interface
3. Keep this terminal session open for monitoring

## Tab Instructions

### Tab 1 - Start Immediately
Copy and paste the contents of `ORCHESTRATOR_BATCH_1A.md` into Tab 1
- Processes: S0343-S0372 (30 seeds)
- Start time: Now

### Tab 2 - Wait 2 Minutes
After Tab 1 has spawned its first mini-batch (after ~2 minutes):
Copy and paste the contents of `ORCHESTRATOR_BATCH_1B.md` into Tab 2
- Processes: S0373-S0402 (30 seeds)
- Start time: +2 minutes from Tab 1

### Tab 3 - Wait 4 Minutes
After Tab 1 has finished its first mini-batch (after ~4 minutes):
Copy and paste the contents of `ORCHESTRATOR_BATCH_1C.md` into Tab 3
- Processes: S0403-S0432 (30 seeds)
- Start time: +4 minutes from Tab 1

## Monitoring

The watch_for_pushes.sh script is already running in this terminal. It will show you:
- When new branches arrive
- Files being extracted
- Current seed count

You should see messages like:
```
✨ Found 1 new branch(es)! Total: 113
📦 Extracting data from new branches...
  Processing: origin/baskets-cmn_for_eng-batch1a-mb1
    - Extracting: seed_S0343_baskets.json
    ...
✅ Extraction complete! Total seeds: 352
```

## Expected Timeline

- **T+0**: Tab 1 starts, spawns first 5 agents
- **T+2**: Tab 2 starts, spawns first 5 agents (10 total active)
- **T+4**: Tab 3 starts, spawns first 5 agents (15 total active)
- **T+8**: First mini-batches complete, first pushes to GitHub
- **T+45**: All 90 seeds complete

## What Success Looks Like

After completion:
- 18 new branches on GitHub (6 per tab)
- 90 new basket files extracted locally
- Total seeds: 347 (current) + 90 (new) = 437
- No rate limit errors
- No frozen sessions

## If Something Goes Wrong

**If you see "Session limit reached":**
- Stop spawning new agents
- Wait for current agents to finish
- Continue with remaining tabs after limit resets

**If a mini-batch fails:**
- Note which seeds failed
- We'll add them to a cleanup batch later
- Continue with next mini-batch

**If Claude freezes:**
- Don't panic - the watch script will catch any successful pushes
- Move to next tab
- Failed seeds will be in the gap analysis

## After Batch 1 Completes

Come back here and we'll:
1. Verify all 90 seeds arrived
2. Run consolidation script
3. Plan Batch 2 (remaining 175 seeds)

---

**Ready?** Start Tab 1 now with the prompt from `ORCHESTRATOR_BATCH_1A.md`!
