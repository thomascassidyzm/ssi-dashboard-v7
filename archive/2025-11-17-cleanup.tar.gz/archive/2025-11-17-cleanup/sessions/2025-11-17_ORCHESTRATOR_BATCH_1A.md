# Orchestrator Prompt - Batch 1A (Tab 1)

**Course**: cmn_for_eng
**Seeds to Process**: S0343-S0372 (30 seeds)
**Strategy**: 6 mini-batches of 5 agents each

---

## Your Task

You are orchestrating Phase 5 LEGO basket generation for Chinese language course. Process seeds S0343 through S0372 using a controlled batching approach.

### Repository Setup
```bash
git clone https://github.com/zenjin/ssi-dashboard-v7-clean.git
cd ssi-dashboard-v7-clean
```

### Execution Plan

Process seeds in **6 mini-batches of 5 seeds each**. After each mini-batch completes, push to GitHub before starting the next.

#### Mini-Batch 1: S0343-S0347
Spawn 5 agents in parallel, each generating 1 seed:
- Agent 1: S0343
- Agent 2: S0344
- Agent 3: S0345
- Agent 4: S0346
- Agent 5: S0347

Wait for all 5 to complete. Then push:
```bash
git add public/vfs/courses/cmn_for_eng/phase5_outputs/seed_S034[3-7]_baskets.json
git commit -m "Phase 5 baskets: S0343-S0347"
git push origin HEAD:baskets-cmn_for_eng-batch1a-mb1
```

#### Mini-Batch 2: S0348-S0352
Repeat with seeds S0348-S0352, push to `baskets-cmn_for_eng-batch1a-mb2`

#### Mini-Batch 3: S0353-S0357
Process S0353-S0357, push to `baskets-cmn_for_eng-batch1a-mb3`

#### Mini-Batch 4: S0358-S0362
Process S0358-S0362, push to `baskets-cmn_for_eng-batch1a-mb4`

#### Mini-Batch 5: S0363-S0367
Process S0363-S0367, push to `baskets-cmn_for_eng-batch1a-mb5`

#### Mini-Batch 6: S0368-S0372
Process S0368-S0372, push to `baskets-cmn_for_eng-batch1a-mb6`

### Agent Instructions Template

Each agent should receive this prompt:

```
Generate Phase 5 LEGO basket data for seed S0XXX in the cmn_for_eng course.

1. Read the seed data from public/vfs/courses/cmn_for_eng/seedsJSON/seed_S0XXX.json
2. Generate practice phrases following the Phase 5 LEGO basket format
3. Save to public/vfs/courses/cmn_for_eng/phase5_outputs/seed_S0XXX_baskets.json

Use the existing basket files as reference for the correct format.
```

### Success Criteria
- ✅ All 30 basket files generated
- ✅ 6 successful GitHub pushes
- ✅ No rate limit errors
- ✅ Files visible in GitHub branches

### Important Notes
- **Wait** for each mini-batch to complete before starting next
- **Don't spawn all 30 at once** - this causes rate limits
- Report progress after each mini-batch
