# Master Orchestrator Template - Phase 5 Basket Generation

**IMPORTANT**: This template is for the ORCHESTRATOR running in each browser window. The orchestrator will spawn sub-agents, but only the orchestrator pushes to GitHub.

---

## Template Variables (Fill these in for each window)

```
ORCHESTRATOR_NUMBER: [1-10]
SEED_RANGE_START: S0XXX
SEED_RANGE_END: S0YYY
TOTAL_SEEDS: [usually 32]
SESSION_ID: [Your Claude Code session ID - find this in your browser URL or run: echo $CLAUDE_SESSION_ID]
```

---

## Master Orchestrator Prompt

```markdown
# Phase 5 Basket Generation - Orchestrator {ORCHESTRATOR_NUMBER}

You are the master orchestrator for Phase 5 basket generation. You will spawn sub-agents to generate basket files, but YOU (the orchestrator) are responsible for all git operations.

## Your Assignment

**Seeds to Process**: {SEED_RANGE_START} through {SEED_RANGE_END} ({TOTAL_SEEDS} seeds)
**Repository**: https://github.com/zenjin/ssi-dashboard-v7-clean.git
**Target Branch**: baskets-cmn_for_eng-{SEED_RANGE_START}-{SEED_RANGE_END}-{SESSION_ID}

## Critical Instructions

### 1. Session ID and Branch Naming

⚠️ **CRITICAL**: Your session ID is: {SESSION_ID}

ALL git branches MUST end with this exact session ID. Sub-agents will have different session IDs - ignore them. Only use YOUR session ID ({SESSION_ID}) in branch names.

### 2. Git Strategy: Local Commits, Single Push

❌ DO NOT push after each mini-batch
✅ DO commit locally after each mini-batch
✅ DO push ONCE at the very end after all seeds complete

### 3. Sub-Agent Instructions

When spawning sub-agents, give them this instruction:

```
Generate Phase 5 LEGO basket data for seed {SEED_ID} in the cmn_for_eng course.

1. Read the lego_pairs from: public/vfs/courses/cmn_for_eng/lego_pairs.json
2. Find seed {SEED_ID} and extract its LEGOs
3. Generate practice phrases following the Phase 5 basket format
4. Save to: public/vfs/courses/cmn_for_eng/phase5_outputs/seed_{SEED_ID}_baskets.json

Use existing basket files as reference for the correct format.

IMPORTANT:
- Only generate the basket file, do NOT commit or push
- The orchestrator will handle all git operations
```

## Execution Steps

### Step 1: Repository Setup

```bash
# Clone repository
git clone https://github.com/zenjin/ssi-dashboard-v7-clean.git
cd ssi-dashboard-v7-clean

# Create your working branch
git checkout -b baskets-cmn_for_eng-{SEED_RANGE_START}-{SEED_RANGE_END}-{SESSION_ID}

# Verify you're on the right branch
git branch --show-current
```

Expected output: `baskets-cmn_for_eng-{SEED_RANGE_START}-{SEED_RANGE_END}-{SESSION_ID}`

### Step 2: Process Seeds in Mini-Batches

Calculate mini-batches:
- Total seeds: {TOTAL_SEEDS}
- Mini-batch size: 5 seeds
- Number of mini-batches: {TOTAL_SEEDS} / 5 = ~{TOTAL_SEEDS/5}

For each mini-batch:

#### A. Spawn Agents (in parallel)
```
Spawn 5 agents in parallel using the Task tool
Each agent processes 1 seed from the current mini-batch
Pass them the sub-agent instruction from above
```

#### B. Wait for Completion
```
Wait for ALL 5 agents to finish before proceeding
Verify all 5 basket files were created
```

#### C. Commit Locally (DO NOT PUSH)
```bash
# Add the new basket files
git add public/vfs/courses/cmn_for_eng/phase5_outputs/seed_S*.json

# Commit locally
git commit -m "Mini-batch X: Seeds SXXXX-SYYYY complete"

# DO NOT RUN: git push (not yet!)
```

#### D. Report Progress
```
"✅ Mini-batch X/{TOTAL_MINI_BATCHES} complete: SXXXX-SYYYY"
```

Repeat for all mini-batches until all {TOTAL_SEEDS} seeds are processed.

### Step 3: Verification Before Push

After all mini-batches complete:

```bash
# Count generated files
generated=$(ls public/vfs/courses/cmn_for_eng/phase5_outputs/seed_S0{START_NUM..END_NUM}_baskets.json 2>/dev/null | wc -l | xargs)
echo "Generated: $generated / {TOTAL_SEEDS} seeds"

# Verify all present
if [ "$generated" -eq "{TOTAL_SEEDS}" ]; then
  echo "✅ All seeds complete!"
else
  echo "⚠️ Missing $((TOTAL_SEEDS - generated)) seeds"
  # List what's missing
  ls public/vfs/courses/cmn_for_eng/phase5_outputs/seed_S0{START_NUM..END_NUM}_baskets.json 2>&1 | grep "No such"
fi
```

### Step 4: Single Push to GitHub

⚠️ **CRITICAL**: Only proceed if all {TOTAL_SEEDS} seeds are present!

```bash
# Verify branch name (must end with your session ID)
git branch --show-current
# Should show: baskets-cmn_for_eng-{SEED_RANGE_START}-{SEED_RANGE_END}-{SESSION_ID}

# Push everything at once
git push origin baskets-cmn_for_eng-{SEED_RANGE_START}-{SEED_RANGE_END}-{SESSION_ID}
```

### Step 5: Report Success

If push succeeds:
```
🎉 SUCCESS! All {TOTAL_SEEDS} seeds pushed to GitHub!

Branch: baskets-cmn_for_eng-{SEED_RANGE_START}-{SEED_RANGE_END}-{SESSION_ID}
Seeds: {SEED_RANGE_START} through {SEED_RANGE_END}
Files: {TOTAL_SEEDS} basket files

Total LEGOs: [count from files]
Total practice phrases: [count from files]
```

## Error Recovery

### If Sub-Agent Fails
```
- Note which seed failed
- Re-spawn just that one agent
- Continue with remaining mini-batches
- At end, verify all seeds present before pushing
```

### If Git Push Fails with 403 Forbidden
```
Most common cause: Branch name doesn't end with correct session ID

Fix:
1. Check current branch name: git branch --show-current
2. Verify it ends with: {SESSION_ID}
3. If wrong, rename: git branch -m baskets-cmn_for_eng-{SEED_RANGE_START}-{SEED_RANGE_END}-{SESSION_ID}
4. Retry push
```

### If Some Seeds Missing at Verification
```
1. Identify missing seeds
2. Spawn agents for only the missing seeds
3. Wait for completion
4. Commit: git commit -m "Filled gaps: SXXX, SYYY"
5. Re-verify count
6. Then push
```

## Mini-Batch Calculation Helper

For {TOTAL_SEEDS} seeds with 5 per mini-batch:

```
Mini-Batch 1: {SEED_RANGE_START}+0  through {SEED_RANGE_START}+4   (5 seeds)
Mini-Batch 2: {SEED_RANGE_START}+5  through {SEED_RANGE_START}+9   (5 seeds)
Mini-Batch 3: {SEED_RANGE_START}+10 through {SEED_RANGE_START}+14  (5 seeds)
Mini-Batch 4: {SEED_RANGE_START}+15 through {SEED_RANGE_START}+19  (5 seeds)
Mini-Batch 5: {SEED_RANGE_START}+20 through {SEED_RANGE_START}+24  (5 seeds)
Mini-Batch 6: {SEED_RANGE_START}+25 through {SEED_RANGE_START}+29  (5 seeds)
Mini-Batch 7: {SEED_RANGE_START}+30 through {SEED_RANGE_START}+31  (2 seeds) [if 32 total]
```

## Checklist

Before starting:
- [ ] Filled in all template variables
- [ ] Verified session ID is correct
- [ ] Confirmed seed range assignment

During execution:
- [ ] Repository cloned successfully
- [ ] Branch created with correct name (ends with session ID)
- [ ] Processing seeds in mini-batches of 5
- [ ] Committing locally after each mini-batch
- [ ] NOT pushing until all complete

Before final push:
- [ ] All {TOTAL_SEEDS} basket files present
- [ ] Branch name ends with {SESSION_ID}
- [ ] All commits made locally

After push:
- [ ] Push succeeded
- [ ] Branch visible on GitHub
- [ ] Files present in branch on GitHub

## Key Principles

1. **One orchestrator = One branch** (not 60+ branches per orchestrator)
2. **Orchestrator controls git** (sub-agents only generate files)
3. **Session ID consistency** (all branches end with orchestrator's session ID)
4. **Commit often, push once** (local commits after each mini-batch, single push at end)
5. **Verify before push** (confirm all seeds present before pushing)

---

## Example Filled Template (Orchestrator 1)

```markdown
# Phase 5 Basket Generation - Orchestrator 1

**Seeds to Process**: S0343 through S0374 (32 seeds)
**Session ID**: 01ABC123XYZ456
**Target Branch**: baskets-cmn_for_eng-S0343-S0374-01ABC123XYZ456

[... rest of template with filled values ...]
```
```
