# Orchestrator Prompt - Batch 1C (Tab 3)

**Course**: cmn_for_eng
**Seeds to Process**: S0403-S0432 (30 seeds)
**Strategy**: 6 mini-batches of 5 agents each

---

## Your Task

You are orchestrating Phase 5 LEGO basket generation for Chinese language course. Process seeds S0403 through S0432 using a controlled batching approach.

### Repository Setup
```bash
git clone https://github.com/zenjin/ssi-dashboard-v7-clean.git
cd ssi-dashboard-v7-clean
```

### Execution Plan

**IMPORTANT**: Wait 4 minutes after starting Tab 1 before beginning, to stagger load.

Process seeds in **6 mini-batches of 5 seeds each**. After each mini-batch completes, push to GitHub before starting the next.

#### Mini-Batch 1: S0403-S0407
Spawn 5 agents in parallel, each generating 1 seed:
- Agent 1: S0403
- Agent 2: S0404
- Agent 3: S0405
- Agent 4: S0406
- Agent 5: S0407

Wait for all 5 to complete. Then push:
```bash
git add public/vfs/courses/cmn_for_eng/phase5_outputs/seed_S040[3-7]_baskets.json
git commit -m "Phase 5 baskets: S0403-S0407"
git push origin HEAD:baskets-cmn_for_eng-batch1c-mb1
```

#### Mini-Batch 2: S0408-S0412
Process S0408-S0412, push to `baskets-cmn_for_eng-batch1c-mb2`

#### Mini-Batch 3: S0413-S0417
Process S0413-S0417, push to `baskets-cmn_for_eng-batch1c-mb3`

#### Mini-Batch 4: S0418-S0422
Process S0418-S0422, push to `baskets-cmn_for_eng-batch1c-mb4`

#### Mini-Batch 5: S0423-S0427
Process S0423-S0427, push to `baskets-cmn_for_eng-batch1c-mb5`

#### Mini-Batch 6: S0428-S0432
Process S0428-S0432, push to `baskets-cmn_for_eng-batch1c-mb6`

### Agent Instructions Template

Each agent should receive this prompt:

```
Generate Phase 5 LEGO basket data for seed S0XXX in the cmn_for_eng course.

1. Read the seed data from public/vfs/courses/cmn_for_eng/seedsJSON/seed_S0XXX.json
2. Generate practice phrases following the Phase 5 LEGO basket format
3. Save to public/vfs/courses/cmn_for_eng/phase5_outputs/seed_S0XXX_baskets.json

Use the existing basket files as reference for the correct format.
```

### Success Criteria
- ✅ All 30 basket files generated
- ✅ 6 successful GitHub pushes
- ✅ No rate limit errors
- ✅ Files visible in GitHub branches

### Important Notes
- **Wait 4 minutes** after Tab 1 starts before beginning
- **Wait** for each mini-batch to complete before starting next
- **Don't spawn all 30 at once** - this causes rate limits
- Report progress after each mini-batch
