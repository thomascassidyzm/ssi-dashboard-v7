# Phase 5 Production Workflow - Standard Operating Procedure

## Overview

This document defines the **standard workflow** for generating Phase 5 LEGO baskets for any 668-seed language course.

---

## Part 1: Current Situation (cmn_for_eng)

### Status
- ✅ **422/668 seeds complete** (63.2%)
- 🎯 **246 seeds remaining**
- 📊 **Recovery rate**: +75 seeds from browser sessions

### Remaining Seeds
See `/tmp/current_missing_seeds.txt` for complete list.

**Top gaps:**
1. S0133-S0192 (60 seeds)
2. S0343-S0384 (42 seeds)
3. S0043-S0072 (30 seeds)
4. S0403-S0432 (30 seeds)
5. S0613-S0642 (30 seeds)
6. Plus smaller gaps totaling 54 seeds

---

## Part 2: Lessons Learned

### ✅ What Worked

1. **Scaffold generation by orchestrator** (not in git)
   - Fast (~1 second for 50 seeds)
   - No repository bloat
   - Self-contained

2. **One branch per orchestrator window**
   - Multiple commits to same branch works!
   - Clean GitHub organization
   - Easy to track progress

3. **Mini-batch processing**
   - 5 agents spawned at a time
   - Reduces concurrent load
   - Manageable failure recovery

4. **Session ID in branch names**
   - Must use orchestrator's session ID
   - Sub-agents have different IDs (ignore them)

5. **Moderate parallelization**
   - 5-6 orchestrator windows maximum
   - 10 agents per window
   - 50 concurrent agents total (safe zone)

### ❌ What Failed

1. **Massive parallelization**
   - 240 concurrent sessions hit rate limits
   - Sessions freeze without graceful failure
   - Recovery is difficult

2. **Individual branches per mini-batch**
   - Creates 100+ branches
   - Hard to manage
   - GitHub clutter

3. **Tracking scaffolds in git**
   - 8.2MB for 668 files
   - Push failures
   - Unnecessary repository bloat

4. **Unclear file paths in prompts**
   - Agents looked for wrong scaffold names
   - Wasted time searching
   - Need explicit paths in instructions

---

## Part 3: Standard Workflow (For Any 668-Seed Course)

### Prerequisites

1. **lego_pairs.json** exists in repository (~1.4MB)
2. **Course code** (e.g., `cmn_for_eng`, `spa_for_eng`)
3. **GitHub repository** cloned and accessible

### Recommended Parameters

| Parameter | Value | Reasoning |
|-----------|-------|-----------|
| **Windows** | 5-6 | Manageable to monitor |
| **Agents per window** | 10 | Proven stable |
| **Seeds per agent** | 5 | Good balance of speed vs risk |
| **Seeds per window** | 50 | 10 agents × 5 seeds |
| **Total capacity** | 300 | 6 windows × 50 seeds |
| **Concurrent agents** | 50-60 | Well under rate limits |
| **Total branches** | 6 | One per window |
| **Duration estimate** | 2-3 hours | For full 668 seeds |

### Resource Allocation

For **668 seeds** divided across **6 windows**:

```
Window 1: Seeds 001-112  (112 seeds)
Window 2: Seeds 113-223  (111 seeds)
Window 3: Seeds 224-334  (111 seeds)
Window 4: Seeds 335-445  (111 seeds)
Window 5: Seeds 446-556  (111 seeds)
Window 6: Seeds 557-668  (112 seeds)
```

Each window runs **10-12 mini-batches** of 10 agents processing 5 seeds each.

---

## Part 4: Orchestrator Prompt Template

### Standard Template Structure

```markdown
# Phase 5 Basket Generation - Window {NUM}

**Course**: {COURSE_CODE}
**Seeds**: S{START:04d}-S{END:04d} ({COUNT} seeds)
**Your Session ID**: {SESSION_ID}
**Branch**: baskets-{COURSE_CODE}-s{START:04d}-s{END:04d}-{SESSION_ID}

---

## Step 1: Repository Setup

```bash
git clone https://github.com/{ORG}/{REPO}.git
cd {REPO}
git checkout -b baskets-{COURSE_CODE}-s{START:04d}-s{END:04d}-{SESSION_ID}
```

**CRITICAL**: Verify branch name ends with YOUR session ID: `{SESSION_ID}`

---

## Step 2: Generate Scaffolds

This creates scaffolds ONLY for your assigned seeds ({START}-{END}):

```bash
node << 'SCAFFOLD_GEN'
const fs = require('fs');

// Read lego_pairs.json
const legoPairs = JSON.parse(
  fs.readFileSync('public/vfs/courses/{COURSE_CODE}/lego_pairs.json', 'utf8')
);

// Create scaffolds directory
fs.mkdirSync('public/vfs/courses/{COURSE_CODE}/phase5_scaffolds', { recursive: true });

// Generate scaffolds for your seeds
for (let seedNum = {START}; seedNum <= {END}; seedNum++) {
  const seedId = \`S\${String(seedNum).padStart(4, '0')}\`;
  const seedData = legoPairs.seeds.find(s => s.seed_id === seedId);

  if (!seedData) {
    console.log(\`⚠️  \${seedId} not found in lego_pairs.json\`);
    continue;
  }

  // Build scaffold with hierarchy
  const scaffold = {
    seed_id: seedId,
    seed_pair: seedData.seed_pair,
    legos: seedData.legos.filter(lego => lego.new === true).map(lego => ({
      id: lego.id,
      type: lego.type,
      lego: [lego.known, lego.target],
      current_seed_earlier_legos: seedData.legos
        .filter(l => l.new === true && parseInt(l.id.match(/L(\d+)/)[1]) < parseInt(lego.id.match(/L(\d+)/)[1]))
        .map(l => ({ id: l.id, known: l.known, target: l.target, type: l.type })),
      phrase_distribution: {
        short_1_to_2_legos: 2,
        medium_3_legos: 2,
        longer_4_legos: 2,
        longest_5_legos: 4
      },
      target_phrase_count: 10
    }))
  };

  const filename = \`public/vfs/courses/{COURSE_CODE}/phase5_scaffolds/seed_s\${String(seedNum).padStart(4, '0')}.json\`;
  fs.writeFileSync(filename, JSON.stringify(scaffold, null, 2));
  console.log(\`✅ \${seedId}\`);
}

console.log(\`\\n🎉 Scaffolds generated for S{START:04d}-S{END:04d}\`);
SCAFFOLD_GEN
```

---

## Step 3: Process Seeds in Mini-Batches

Process your {COUNT} seeds in mini-batches of **10 agents × 5 seeds = 50 seeds per batch**.

### Mini-Batch {BATCH_NUM}: S{BATCH_START:04d}-S{BATCH_END:04d}

#### A. Spawn 10 Agents (parallel)

Use Task tool to spawn 10 agents. Each agent gets this instruction:

```
Generate Phase 5 LEGO baskets for seeds {SEED1}, {SEED2}, {SEED3}, {SEED4}, {SEED5}.

For EACH seed:

1. Read scaffold: public/vfs/courses/{COURSE_CODE}/phase5_scaffolds/seed_s{NUM}.json
   (lowercase 's', 4-digit padded number)

2. For each LEGO in the scaffold:
   - Generate 10 practice phrases following phrase_distribution:
     * 2 short (1-2 LEGOs)
     * 2 medium (3 LEGOs)
     * 2 longer (4 LEGOs)
     * 4 longest (5 LEGOs)
   - Use current_seed_earlier_legos for building combinations

3. Save basket: public/vfs/courses/{COURSE_CODE}/phase5_outputs/seed_{SEED_ID}_baskets.json
   (capital 'S', with _baskets suffix)

Example:
- Read: seed_s0115.json
- Write: seed_S0115_baskets.json

DO NOT do any git operations - orchestrator handles that.
```

#### B. Wait for Completion

Wait for ALL 10 agents to finish. Verify files created:

```bash
ls public/vfs/courses/{COURSE_CODE}/phase5_outputs/seed_S{BATCH_START:04d}*.json
# Should show 50 files
```

#### C. Commit and Push

```bash
# Add new basket files
git add public/vfs/courses/{COURSE_CODE}/phase5_outputs/seed_S*.json

# Commit
git commit -m "Batch {BATCH_NUM}: S{BATCH_START:04d}-S{BATCH_END:04d} (50 seeds)"

# Push to YOUR branch (same branch every time!)
git push origin baskets-{COURSE_CODE}-s{START:04d}-s{END:04d}-{SESSION_ID}
```

#### D. Report Progress

```
✅ Batch {BATCH_NUM}/{TOTAL_BATCHES} complete: S{BATCH_START:04d}-S{BATCH_END:04d}
   Progress: {COMPLETED}/{COUNT} seeds ({PERCENT}%)
```

**Repeat** for all mini-batches until all {COUNT} seeds complete.

---

## Step 4: Final Verification

After all mini-batches:

```bash
# Count your basket files
count=$(ls public/vfs/courses/{COURSE_CODE}/phase5_outputs/seed_S{START:04d}*.json 2>/dev/null | wc -l)
echo "Generated: $count / {COUNT} seeds"

# Verify range
missing=$(comm -23 \
  <(seq {START} {END} | awk '{printf "S%04d\\n", $1}' | sort) \
  <(ls public/vfs/courses/{COURSE_CODE}/phase5_outputs/seed_S*.json | grep -oE 'S[0-9]{4}' | sort) \
)

if [ -z "$missing" ]; then
  echo "✅ All {COUNT} seeds complete!"
else
  echo "⚠️  Missing seeds:"
  echo "$missing"
fi
```

---

## Success Criteria

- ✅ All {COUNT} basket files generated
- ✅ All commits pushed to single branch
- ✅ Branch visible on GitHub
- ✅ No missing seeds in your range
- ✅ Working tree clean

---

## If Something Goes Wrong

### Agent Fails
- Note which seed(s) failed
- Re-spawn agent for just those seeds
- Continue with next mini-batch

### Git Push Fails (403 Error)
```bash
# Check branch name ends with YOUR session ID
git branch --show-current
# Should end with: {SESSION_ID}

# If wrong, rename:
git branch -m baskets-{COURSE_CODE}-s{START:04d}-s{END:04d}-{SESSION_ID}

# Retry push
git push origin baskets-{COURSE_CODE}-s{START:04d}-s{END:04d}-{SESSION_ID}
```

### Session Limit Reached
- Wait for limit reset (shown in error message)
- Continue from last completed mini-batch
- Already-pushed commits are safe

---

## After Completion

Report to coordinator:

```
🎉 Window {NUM} Complete!

Branch: baskets-{COURSE_CODE}-s{START:04d}-s{END:04d}-{SESSION_ID}
Seeds: S{START:04d}-S{END:04d} ({COUNT} seeds)
Total LEGOs: [count from files]
Total phrases: [count from files]
Status: ✅ All seeds generated and pushed
```
```

---

## Part 5: Coordination & Consolidation

### Orchestrator Assignment Table

| Window | Seeds | Count | Branch Suffix | Status |
|--------|-------|-------|---------------|--------|
| 1 | S0001-S0112 | 112 | s0001-s0112-{SID} | Pending |
| 2 | S0113-S0223 | 111 | s0113-s0223-{SID} | Pending |
| 3 | S0224-S0334 | 111 | s0224-s0334-{SID} | Pending |
| 4 | S0335-S0445 | 111 | s0335-s0445-{SID} | Pending |
| 5 | S0446-S0556 | 111 | s0446-s0556-{SID} | Pending |
| 6 | S0557-S0668 | 112 | s0557-s0668-{SID} | Pending |

### Monitoring Progress

Run extraction script periodically:

```bash
# Fetch all branches
git fetch --all

# Extract baskets
bash extract_all_baskets.sh

# Check progress
ls public/vfs/courses/{COURSE_CODE}/phase5_outputs/seed_S*_baskets.json | wc -l
# Target: 668
```

### Final Consolidation

After all 6 windows complete:

```bash
# Consolidate all baskets into single file
node scripts/consolidate_baskets.cjs public/vfs/courses/{COURSE_CODE}

# Verify
cat public/vfs/courses/{COURSE_CODE}/lego_baskets.json | jq '.total_baskets'
# Should show total LEGO count

# Commit consolidated file
git checkout main
git add public/vfs/courses/{COURSE_CODE}/lego_baskets.json
git commit -m "Phase 5 complete: all 668 seeds consolidated for {COURSE_CODE}"
git push origin main
```

### Cleanup (Optional)

Delete temporary basket branches:

```bash
git branch -r | grep "baskets-{COURSE_CODE}" | while read branch; do
  git push origin --delete ${branch#origin/}
done
```

---

## Part 6: Quality Checks

### Automated Validation

```bash
# Check basket format
node scripts/validate_baskets.js public/vfs/courses/{COURSE_CODE}

# Check LEGO coverage
node scripts/verify_lego_coverage.js public/vfs/courses/{COURSE_CODE}
```

### Manual Spot Checks

Sample 5-10 random basket files:
- Verify 2-2-2-4 distribution (2 short, 2 medium, 2 longer, 4 longest)
- Check phrase variety (no duplicates)
- Confirm LEGO hierarchy used correctly

---

## Part 7: Timeline Estimates

### For Complete 668-Seed Course

| Phase | Duration | Notes |
|-------|----------|-------|
| Orchestrator setup | 15 min | Create 6 browser tabs, paste prompts |
| Scaffold generation | 1 min/window | Automatic, ~6 min total |
| Basket generation | 90-120 min | Depends on API speed |
| Pushing to GitHub | 10 min | Included in generation |
| Extraction | 10 min | After all complete |
| Consolidation | 2 min | Merge into single file |
| **Total** | **2-3 hours** | End-to-end |

### For Partial Recovery (246 seeds)

Using 5 windows × 50 seeds:

| Phase | Duration |
|-------|----------|
| Setup | 10 min |
| Generation | 60-90 min |
| Consolidation | 2 min |
| **Total** | **1.5-2 hours** |

---

## Part 8: Current Recovery Plan (cmn_for_eng)

### Window Assignments for 246 Missing Seeds

| Window | Seeds | Count | Notes |
|--------|-------|-------|-------|
| 1 | S0133-S0192 | 60 | Largest gap |
| 2 | S0343-S0384, S0388-S0399 | 54 | Combined gaps |
| 3 | S0043-S0072 | 30 | Single range |
| 4 | S0403-S0432 | 30 | Single range |
| 5 | S0613-S0642, S0235-S0249 | 45 | End + middle |
| 6 | All small gaps | 27 | Cleanup |

**Total: 6 windows, 246 seeds, ~1.5-2 hours**

---

## Part 9: Success Metrics

### Per Window
- ✅ All assigned seeds generated
- ✅ One branch created
- ✅ All commits pushed successfully
- ✅ No duplicate files
- ✅ Correct naming (seed_S not seed_s)

### Overall
- ✅ 668/668 seeds complete
- ✅ lego_baskets.json consolidated
- ✅ All baskets follow 2-2-2-4 distribution
- ✅ No missing LEGOs
- ✅ Repository clean

---

## Part 10: Reusability for Other Courses

This workflow is **language-agnostic**. For any new 668-seed course:

1. Replace `{COURSE_CODE}` (e.g., `fra_for_eng`, `ita_for_eng`)
2. Ensure `lego_pairs.json` exists for that course
3. Use same 6-window split
4. Follow identical orchestrator template
5. Same consolidation process

**No changes needed** to core workflow!

---

## Appendix: File Naming Reference

| Item | Path Pattern | Example |
|------|-------------|---------|
| Lego pairs (source) | `public/vfs/courses/{COURSE}/lego_pairs.json` | `cmn_for_eng/lego_pairs.json` |
| Scaffold (temp, lowercase) | `phase5_scaffolds/seed_s{NUM}.json` | `seed_s0115.json` |
| Basket (output, uppercase) | `phase5_outputs/seed_S{NUM}_baskets.json` | `seed_S0115_baskets.json` |
| Consolidated | `public/vfs/courses/{COURSE}/lego_baskets.json` | `cmn_for_eng/lego_baskets.json` |

**Remember**: Scaffolds use lowercase `s`, baskets use uppercase `S`!
