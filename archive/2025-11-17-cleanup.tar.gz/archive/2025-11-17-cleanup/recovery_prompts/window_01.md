# Phase 5 Basket Generation - Recovery Window 1

**Course**: cmn_for_eng
**Seeds**: S0043-S0063 (21 seeds)
**Your Session ID**: {SESSION_ID} ← **REPLACE WITH YOUR ACTUAL SESSION ID**
**Branch**: baskets-cmn_for_eng-recovery-w01-{SESSION_ID}

---

## Step 1: Repository Setup

```bash
git clone https://github.com/zenjin/ssi-dashboard-v7-clean.git
cd ssi-dashboard-v7-clean
git checkout -b baskets-cmn_for_eng-recovery-w01-{SESSION_ID}
```

**CRITICAL**: Replace {SESSION_ID} with YOUR actual Claude Code session ID before running!

---

## Step 2: Generate Scaffolds

This creates scaffolds ONLY for your assigned seeds (43-63):

```bash
node << 'SCAFFOLD_GEN'
const fs = require('fs');

// Read lego_pairs.json
const legoPairs = JSON.parse(
  fs.readFileSync('public/vfs/courses/cmn_for_eng/lego_pairs.json', 'utf8')
);

// Create scaffolds directory
fs.mkdirSync('public/vfs/courses/cmn_for_eng/phase5_scaffolds', { recursive: true });

// Your assigned seed numbers
const assignedSeeds = [43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63];

// Generate scaffolds
for (const seedNum of assignedSeeds) {
  const seedId = `S${String(seedNum).padStart(4, '0')}`;
  const seedData = legoPairs.seeds.find(s => s.seed_id === seedId);

  if (!seedData) {
    console.log(`⚠️  ${seedId} not found in lego_pairs.json`);
    continue;
  }

  // Build scaffold with hierarchy
  const scaffold = {
    seed_id: seedId,
    seed_pair: seedData.seed_pair,
    legos: seedData.legos.filter(lego => lego.new === true).map(lego => ({
      id: lego.id,
      type: lego.type,
      lego: [lego.known, lego.target],
      current_seed_earlier_legos: seedData.legos
        .filter(l => l.new === true && parseInt(l.id.match(/L(\\d+)/)[1]) < parseInt(lego.id.match(/L(\\d+)/)[1]))
        .map(l => ({ id: l.id, known: l.known, target: l.target, type: l.type })),
      phrase_distribution: {
        short_1_to_2_legos: 2,
        medium_3_legos: 2,
        longer_4_legos: 2,
        longest_5_legos: 4
      },
      target_phrase_count: 10
    }))
  };

  const filename = `public/vfs/courses/cmn_for_eng/phase5_scaffolds/seed_s${String(seedNum).padStart(4, '0')}.json`;
  fs.writeFileSync(filename, JSON.stringify(scaffold, null, 2));
  console.log(`✅ ${seedId}`);
}

console.log(`\\n🎉 Scaffolds generated for S0043-S0063`);
SCAFFOLD_GEN
```

---

## Step 3: Process Seeds with Agents

Process your 21 seeds using **10 agents × ~3 seeds per agent**.

### Agent Instruction Template

Use the Task tool to spawn 10 agents in parallel. Give each agent this instruction:

```
Generate Phase 5 LEGO baskets for seeds {SEED_LIST}.

For EACH seed:

1. Read scaffold: public/vfs/courses/cmn_for_eng/phase5_scaffolds/seed_s{NUM}.json
   (lowercase 's', 4-digit padded number)

2. For each LEGO in the scaffold:
   - Generate 10 practice phrases following phrase_distribution:
     * 2 short (1-2 LEGOs)
     * 2 medium (3 LEGOs)
     * 2 longer (4 LEGOs)
     * 4 longest (5 LEGOs)
   - Use current_seed_earlier_legos for building combinations

3. Save basket: public/vfs/courses/cmn_for_eng/phase5_outputs/seed_{SEED_ID}_baskets.json
   (capital 'S', with _baskets suffix)

Example:
- Read: seed_s0115.json
- Write: seed_S0115_baskets.json

DO NOT do any git operations - orchestrator handles that.
```

### Agent Seed Assignments

Spawn all 10 agents at once with these assignments:

- Agent 1: S0043, S0044, S0045
- Agent 2: S0046, S0047, S0048
- Agent 3: S0049, S0050, S0051
- Agent 4: S0052, S0053, S0054
- Agent 5: S0055, S0056, S0057
- Agent 6: S0058, S0059, S0060
- Agent 7: S0061, S0062, S0063

---

## Step 4: Wait for Completion

Wait for ALL agents to finish. Verify files created:

```bash
ls public/vfs/courses/cmn_for_eng/phase5_outputs/seed_S*.json | wc -l
# Should show approximately 21 files
```

---

## Step 5: Commit and Push

```bash
# Add new basket files
git add public/vfs/courses/cmn_for_eng/phase5_outputs/seed_S*.json

# Commit
git commit -m "Recovery Window 1: S0043-S0063 (21 seeds)"

# Push to YOUR branch (with your session ID!)
git push origin baskets-cmn_for_eng-recovery-w01-{{SESSION_ID}}
```

---

## Step 6: Final Verification

```bash
# Count your basket files
count=$(ls public/vfs/courses/cmn_for_eng/phase5_outputs/seed_S*.json 2>/dev/null | wc -l)
echo "Generated: $count / 21 seeds"

# List any missing seeds from your assignment
expected="S0043 S0044 S0045 S0046 S0047 S0048 S0049 S0050 S0051 S0052 S0053 S0054 S0055 S0056 S0057 S0058 S0059 S0060 S0061 S0062 S0063"
for seed in $expected; do
  if [ ! -f "public/vfs/courses/cmn_for_eng/phase5_outputs/seed_${seed}_baskets.json" ]; then
    echo "⚠️  Missing: $seed"
  fi
done
```

---

## Success Criteria

- ✅ All 21 basket files generated
- ✅ All commits pushed to single branch
- ✅ Branch visible on GitHub
- ✅ No missing seeds in your assignment
- ✅ Working tree clean

---

## Report When Complete

```
🎉 Recovery Window 1 Complete!

Branch: baskets-cmn_for_eng-recovery-w01-{{SESSION_ID}}
Seeds: S0043-S0063 (21 seeds)
Status: ✅ All seeds generated and pushed
```
