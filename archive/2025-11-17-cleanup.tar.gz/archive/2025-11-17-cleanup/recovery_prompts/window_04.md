# Phase 5 Basket Generation - Recovery Window 4

**Course**: cmn_for_eng
**Seeds**: S0163-S0183 (21 seeds)
**Your Session ID**: {SESSION_ID} ← **REPLACE WITH YOUR ACTUAL SESSION ID**
**Branch**: baskets-cmn_for_eng-recovery-w04-{SESSION_ID}

---

## Step 1: Repository Setup

```bash
git clone https://github.com/zenjin/ssi-dashboard-v7-clean.git
cd ssi-dashboard-v7-clean
git checkout -b baskets-cmn_for_eng-recovery-w04-{SESSION_ID}
```

**CRITICAL**: Replace {SESSION_ID} with YOUR actual Claude Code session ID before running!

---

## Step 2: Generate Scaffolds

This creates scaffolds ONLY for your assigned seeds (163-183):

```bash
node << 'SCAFFOLD_GEN'
const fs = require('fs');

// Read lego_pairs.json
const legoPairs = JSON.parse(
  fs.readFileSync('public/vfs/courses/cmn_for_eng/lego_pairs.json', 'utf8')
);

// Create scaffolds directory
fs.mkdirSync('public/vfs/courses/cmn_for_eng/phase5_scaffolds', { recursive: true });

// Your assigned seed numbers
const assignedSeeds = [163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183];

// Generate scaffolds
for (const seedNum of assignedSeeds) {
  const seedId = `S${String(seedNum).padStart(4, '0')}`;
  const seedData = legoPairs.seeds.find(s => s.seed_id === seedId);

  if (!seedData) {
    console.log(`⚠️  ${seedId} not found in lego_pairs.json`);
    continue;
  }

  // Build scaffold with hierarchy
  const scaffold = {
    seed_id: seedId,
    seed_pair: seedData.seed_pair,
    legos: seedData.legos.filter(lego => lego.new === true).map(lego => ({
      id: lego.id,
      type: lego.type,
      lego: [lego.known, lego.target],
      current_seed_earlier_legos: seedData.legos
        .filter(l => l.new === true && parseInt(l.id.match(/L(\\d+)/)[1]) < parseInt(lego.id.match(/L(\\d+)/)[1]))
        .map(l => ({ id: l.id, known: l.known, target: l.target, type: l.type })),
      phrase_distribution: {
        short_1_to_2_legos: 2,
        medium_3_legos: 2,
        longer_4_legos: 2,
        longest_5_legos: 4
      },
      target_phrase_count: 10
    }))
  };

  const filename = `public/vfs/courses/cmn_for_eng/phase5_scaffolds/seed_s${String(seedNum).padStart(4, '0')}.json`;
  fs.writeFileSync(filename, JSON.stringify(scaffold, null, 2));
  console.log(`✅ ${seedId}`);
}

console.log(`\\n🎉 Scaffolds generated for S0163-S0183`);
SCAFFOLD_GEN
```

---

## Step 3: Process Seeds with Agents

Process your 21 seeds using **10 agents × ~3 seeds per agent**.

### Agent Instruction Template

Use the Task tool to spawn 10 agents in parallel. Give each agent this instruction:

```
Generate Phase 5 LEGO baskets for seeds {SEED_LIST}.

For EACH seed:

1. Read scaffold: public/vfs/courses/cmn_for_eng/phase5_scaffolds/seed_s{NUM}.json
   (lowercase 's', 4-digit padded number)

2. For each LEGO in the scaffold:
   - Generate 10 practice phrases following phrase_distribution:
     * 2 short (1-2 LEGOs)
     * 2 medium (3 LEGOs)
     * 2 longer (4 LEGOs)
     * 4 longest (5 LEGOs)
   - Use current_seed_earlier_legos for building combinations

3. Save basket: public/vfs/courses/cmn_for_eng/phase5_outputs/seed_{SEED_ID}_baskets.json
   (capital 'S', with _baskets suffix)

Example:
- Read: seed_s0115.json
- Write: seed_S0115_baskets.json

DO NOT do any git operations - orchestrator handles that.
```

### Agent Seed Assignments

Spawn all 10 agents at once with these assignments:

- Agent 1: S0163, S0164, S0165
- Agent 2: S0166, S0167, S0168
- Agent 3: S0169, S0170, S0171
- Agent 4: S0172, S0173, S0174
- Agent 5: S0175, S0176, S0177
- Agent 6: S0178, S0179, S0180
- Agent 7: S0181, S0182, S0183

---

## Step 4: Wait for Completion

Wait for ALL agents to finish. Verify files created:

```bash
ls public/vfs/courses/cmn_for_eng/phase5_outputs/seed_S*.json | wc -l
# Should show approximately 21 files
```

---

## Step 5: Commit and Push

```bash
# Add new basket files
git add public/vfs/courses/cmn_for_eng/phase5_outputs/seed_S*.json

# Commit
git commit -m "Recovery Window 4: S0163-S0183 (21 seeds)"

# Push to YOUR branch (with your session ID!)
git push origin baskets-cmn_for_eng-recovery-w04-{{SESSION_ID}}
```

---

## Step 6: Final Verification

```bash
# Count your basket files
count=$(ls public/vfs/courses/cmn_for_eng/phase5_outputs/seed_S*.json 2>/dev/null | wc -l)
echo "Generated: $count / 21 seeds"

# List any missing seeds from your assignment
expected="S0163 S0164 S0165 S0166 S0167 S0168 S0169 S0170 S0171 S0172 S0173 S0174 S0175 S0176 S0177 S0178 S0179 S0180 S0181 S0182 S0183"
for seed in $expected; do
  if [ ! -f "public/vfs/courses/cmn_for_eng/phase5_outputs/seed_${seed}_baskets.json" ]; then
    echo "⚠️  Missing: $seed"
  fi
done
```

---

## Success Criteria

- ✅ All 21 basket files generated
- ✅ All commits pushed to single branch
- ✅ Branch visible on GitHub
- ✅ No missing seeds in your assignment
- ✅ Working tree clean

---

## Report When Complete

```
🎉 Recovery Window 4 Complete!

Branch: baskets-cmn_for_eng-recovery-w04-{{SESSION_ID}}
Seeds: S0163-S0183 (21 seeds)
Status: ✅ All seeds generated and pushed
```
